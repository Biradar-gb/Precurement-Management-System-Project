package com.pms.precurement_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrecurementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrecurementSystemApplication.class, args);
	}

}
