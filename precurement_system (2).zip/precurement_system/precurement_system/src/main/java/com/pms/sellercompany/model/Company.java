package com.pms.sellercompany.model;


import jakarta.persistence.*;
import org.hibernate.engine.internal.Cascade;

import javax.persistence.Table;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "company_details")
public class Company {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "rigister_num")
    private String register_Number;


    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "company_address_id", referencedColumnName = "id")
    private Company_Contact addresssId;

    @Transient
    private String address_id;


    @OneToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name = "company_legal_details_id", referencedColumnName = "id")
    private Company_Documents legalDetails;

    @Transient
    private Integer company_legal_details_id;

    @OneToMany(targetEntity = User.class, cascade = CascadeType.MERGE)
    private List<User> user;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegister_Number() {
        return register_Number;
    }

    public void setRegister_Number(String register_Number) {
        this.register_Number = register_Number;
    }

    public Company_Contact getAddresssId() {
        return addresssId;
    }

    public void setAddresssId(Company_Contact addresssId) {
        this.addresssId = addresssId;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public Company_Documents getLegalDetails() {
        return legalDetails;
    }

    public void setLegalDetails(Company_Documents legalDetails) {
        this.legalDetails = legalDetails;
    }

    public Integer getCompany_legal_details_id() {
        return company_legal_details_id;
    }

    public void setCompany_legal_details_id(Integer company_legal_details_id) {
        this.company_legal_details_id = company_legal_details_id;
    }

    public List<User> getUser() {
        return user;
    }

    public void setUser(List<User> user) {
        this.user = user;
    }
}