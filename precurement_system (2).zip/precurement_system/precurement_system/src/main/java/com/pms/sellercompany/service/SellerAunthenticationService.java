package com.pms.sellercompany.service;

import com.pms.sellercompany.dto.CompanyDto;
import com.pms.sellercompany.model.User;
import com.pms.sellercompany.repository.SellerAuthRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SellerAunthenticationService {
@Autowired
SellerAuthRepository sellerAuthRepository;

    public CompanyDto createsellerSignup(CompanyDto companyDto) {

        return sellerAuthRepository.createsellerSignup(companyDto);
    }
}
