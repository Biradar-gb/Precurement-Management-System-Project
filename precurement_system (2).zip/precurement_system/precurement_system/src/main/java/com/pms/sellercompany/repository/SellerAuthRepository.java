package com.pms.sellercompany.repository;

import com.pms.sellercompany.dto.CompanyDto;
import com.pms.sellercompany.model.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.springframework.stereotype.Repository;

@Repository
public class SellerAuthRepository {


    public CompanyDto createsellerSignup(CompanyDto companyDto) {

        User user = new User();
        user.setUser_name((companyDto.getUser().getUser_name()));
        user.setUser_password(companyDto.getUser().getUser_password());

        Login login = new Login();
        login.setPassword(companyDto.getLogin().getPassword());
        login.setUser_name(companyDto.getLogin().getUser_name());

        Company company = new Company();
        company.setName(companyDto.getName());
        company.setRegister_Number(companyDto.getRegister_number());



        Configuration configuration = new Configuration();
        configuration
                .addAnnotatedClass(User.class)
                .addAnnotatedClass(Company.class)
                .addAnnotatedClass(Company_Address.class)
                .addAnnotatedClass(Company_Contact.class)
                .addAnnotatedClass(Company_Documents.class)
                .addAnnotatedClass(Company_Owner.class)
                .addAnnotatedClass(Company_Bank.class)
                .addAnnotatedClass(Location.class)
                .addAnnotatedClass(Login.class)
                .configure("Hibernate.cfg.xml");

        ServiceRegistry sr = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
        SessionFactory sessionFactory = configuration.buildSessionFactory(sr);
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();

        session.persist(company);

        user.setCompany_details(company);
        session.persist(user);


        login.setUser(user);
        session.persist(login);

        tx.commit();
        companyDto.setId(company.getId());
        return companyDto;

    }
}
