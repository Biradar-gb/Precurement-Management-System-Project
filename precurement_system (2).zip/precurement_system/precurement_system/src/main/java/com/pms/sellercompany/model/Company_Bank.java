package com.pms.sellercompany.model;

import jakarta.persistence.*;

@Entity
@Table(name="company_bank_details")
public class Company_Bank {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer  id;

    @Column(name="name")
    private String name;

    @Column(name="accont_number")
     private Long account_number;

     @Column(name="branch")
     private String branch;

     @Column(name="ifsc_code")
     private String ifsc_code;

     @Column(name="pan_number")
     private String pan_number;

     @OneToOne(cascade = CascadeType.MERGE)
     @JoinColumn(name="company_details_id",referencedColumnName = "id")
     private Company_Contact  company_details;

     @Transient
     private Integer  company_details_id;


}
