package com.pms.sellercompany.model;

import jakarta.persistence.*;
import org.springframework.context.annotation.Lazy;

@Entity
@Table(name="user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name="user_name")
    private String  user_name ;

    @Column(name="user_password")
    private String user_password;

    @Column(name="role")
    private String role;

    @ManyToOne(targetEntity = Company.class,fetch = FetchType.LAZY)
    @JoinColumn(name = "company_details_id" ,referencedColumnName = "id")
    private  Company  Company_details;

    @Transient
    private Integer  company_details_id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_password() {
        return user_password;
    }

    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Company getCompany_details() {
        return Company_details;
    }

    public void setCompany_details(Company company_details) {
        Company_details = company_details;
    }

    public Integer getCompany_details_id() {
        return company_details_id;
    }

    public void setCompany_details_id(Integer company_details_id) {
        this.company_details_id = company_details_id;
    }
}
