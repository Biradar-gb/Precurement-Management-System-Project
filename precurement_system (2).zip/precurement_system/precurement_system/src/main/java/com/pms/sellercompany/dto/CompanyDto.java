package com.pms.sellercompany.dto;

import com.pms.sellercompany.model.Company_Contact;
import com.pms.sellercompany.model.Login;
import com.pms.sellercompany.model.User;

public class CompanyDto {

    private Integer id;
    private String name;
    private String register_number;
    private Company_Contact addresssId;
    private Integer company_legal_details_id;

    private User user;
    private Login login;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRegister_number() {
        return register_number;
    }

    public void setRegister_number(String register_number) {
        this.register_number = register_number;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Login getLogin() {
        return login;
    }

    public void setLogin(Login login) {
        this.login = login;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Company_Contact getAddresssId() {
        return addresssId;
    }

    public void setAddresssId(Company_Contact addresssId) {
        this.addresssId = addresssId;
    }

    public Integer getCompany_legal_details_id() {
        return company_legal_details_id;
    }

    public void setCompany_legal_details_id(Integer company_legal_details_id) {
        this.company_legal_details_id = company_legal_details_id;
    }
}
